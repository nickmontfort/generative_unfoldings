# Readme

To download models run:

```
cd ml5-data-and-models-server
npm run download:all
```

or for specific models:

for example
```
cd ml5-data-and-models-server
npm run download:bodyPix
```